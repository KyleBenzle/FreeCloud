#!/usr/bin/env python3
"""Very small FreeCloud desktop launcher UI for macOS/Linux."""

from __future__ import annotations

import queue
import json
import os
import platform
import subprocess
import sys
import threading
import tkinter as tk
import urllib.parse
import webbrowser
from pathlib import Path
from tkinter import messagebox

import freecloud_cli as cli


BASE_DIR = Path(__file__).resolve().parent
CLI_PATH = BASE_DIR / "freecloud_cli.py"
LAST_CONFIG_PATH = BASE_DIR / ".freecloud_last_config.json"
RUN_SCRIPT = BASE_DIR / "Run_Mac_Linux.sh"
LOGO_PATH = BASE_DIR / "logo.png"
ICON_PATH = BASE_DIR / "icon.png"
BACKGROUND_LOG_PATH = BASE_DIR / "freecloud_background.log"
SYNC_PID_PATH = BASE_DIR / "freecloud_sync.pid"


def load_json(path: Path) -> dict[str, object]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def build_setup_urls(domain_text: str, drive_text: str) -> tuple[str, str, str]:
    domain = cli.normalize_domain(domain_text)
    drive_name = cli.normalize_drive_name(drive_text)
    parsed = urllib.parse.urlparse(domain)
    domain_path = parsed.path.strip("/")

    if domain_path:
        base_url = domain.rstrip("/")
        if drive_text.strip() in {"", "FreeCloud"}:
            drive_name = domain_path.split("/")[-1]
        return domain, drive_name, base_url

    return domain, drive_name, f"{domain}/{drive_name}"


def xml_escape(value: str) -> str:
    return (
        value.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def configure_autostart(enabled: bool) -> Path:
    system = platform.system()
    if system == "Darwin":
        target = Path.home() / "Library" / "LaunchAgents" / "com.freecloud.sync.plist"
        if not enabled:
            target.unlink(missing_ok=True)
            return target
        target.parent.mkdir(parents=True, exist_ok=True)
        content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.freecloud.sync</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/sh</string>
        <string>{xml_escape(str(RUN_SCRIPT))}</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
</dict>
</plist>
"""
        target.write_text(content, encoding="utf-8")
        return target

    target = Path.home() / ".config" / "autostart" / "FreeCloud.desktop"
    if not enabled:
        target.unlink(missing_ok=True)
        return target
    target.parent.mkdir(parents=True, exist_ok=True)
    exec_line = f'sh -c \'cd "{BASE_DIR}" && ./Run_Mac_Linux.sh\''
    target.write_text(
        "\n".join(
            [
                "[Desktop Entry]",
                "Type=Application",
                "Name=FreeCloud Sync",
                "Comment=Start FreeCloud sync",
                f"Exec={exec_line}",
                "Terminal=false",
                "X-GNOME-Autostart-enabled=true",
                "",
            ]
        ),
        encoding="utf-8",
    )
    return target


def is_process_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def read_running_sync_pid() -> int | None:
    try:
        pid = int(SYNC_PID_PATH.read_text(encoding="utf-8").strip())
    except (FileNotFoundError, ValueError):
        return None

    if is_process_running(pid):
        return pid

    try:
        SYNC_PID_PATH.unlink()
    except FileNotFoundError:
        pass
    return None


def configured_paths() -> tuple[str, str]:
    config = load_json(LAST_CONFIG_PATH)
    local_root = config.get("local_root")
    base_url = config.get("base_url")
    return (
        str(local_root) if isinstance(local_root, str) else "",
        str(base_url) if isinstance(base_url, str) else "",
    )


def open_folder(path: str) -> bool:
    if not path:
        return False

    folder = Path(path).expanduser()
    if not folder.exists():
        return False

    commands = []
    if platform.system() == "Darwin":
        commands.append(["open", str(folder)])
    elif platform.system() == "Windows":
        commands.append(["explorer", str(folder)])
    else:
        commands.extend([["xdg-open", str(folder)], ["gio", "open", str(folder)]])

    for command in commands:
        try:
            subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except (FileNotFoundError, OSError):
            continue
    return False


def open_url(url: str) -> bool:
    if not url:
        return False

    if webbrowser.open_new_tab(url):
        return True

    commands = []
    if platform.system() == "Darwin":
        commands.append(["open", url])
    elif platform.system() == "Windows":
        commands.append(["cmd", "/c", "start", "", url])
    else:
        commands.extend([["xdg-open", url], ["gio", "open", url], ["sensible-browser", url]])

    for command in commands:
        try:
            subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except (FileNotFoundError, OSError):
            continue
    return False


class FreeCloudUi:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.process: subprocess.Popen[str] | None = None
        self.output_queue: queue.Queue[str | None] = queue.Queue()

        root.title("FreeCloud Sync")
        root.geometry("720x460")
        root.minsize(520, 340)

        self.status = tk.StringVar(value="Stopped")
        self.domain_var = tk.StringVar(value="https://www.example.com")
        self.drive_var = tk.StringVar(value="FreeCloud")
        self.local_var = tk.StringVar(value=str(Path.home() / "FreeCloud"))
        self.password_var = tk.StringVar(value="")
        self.autostart_var = tk.BooleanVar(value=True)
        self.local_path_var = tk.StringVar(value="Not set")
        self.logo_image: tk.PhotoImage | None = None
        self.icon_image: tk.PhotoImage | None = None

        self.frame = tk.Frame(root, padx=14, pady=14)
        self.frame.pack(fill=tk.BOTH, expand=True)

        self.load_images()

        header = tk.Frame(self.frame)
        header.pack(fill=tk.X)

        if self.logo_image is not None:
            tk.Label(header, image=self.logo_image).pack(side=tk.LEFT, padx=(0, 10))

        header_text = tk.Frame(header)
        header_text.pack(side=tk.LEFT, fill=tk.X, expand=True)

        title = tk.Label(header_text, text="FreeCloud Sync", font=("TkDefaultFont", 18, "bold"))
        title.pack(anchor="w")

        note = tk.Label(
            header_text,
            text="Start syncing your local folder with the web drive. Close this window after stopping sync.",
            anchor="w",
            justify="left",
        )
        note.pack(fill=tk.X, pady=(4, 12))

        local_row = tk.Frame(header_text)
        local_row.pack(fill=tk.X)

        tk.Label(local_row, text="Local Folder:", fg="#000", anchor="w").pack(side=tk.LEFT)

        self.local_link = tk.Label(
            local_row,
            textvariable=self.local_path_var,
            fg="#0645ad",
            cursor="hand2",
            anchor="w",
            justify="left",
            wraplength=460,
        )
        self.local_link.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(4, 0))
        self.local_link.bind("<Button-1>", lambda _event: self.open_local_folder())

        self.setup_frame = tk.LabelFrame(self.frame, text="First-time setup", padx=10, pady=10)
        self.build_setup_form()

        self.buttons_frame = tk.Frame(self.frame)
        self.buttons_frame.pack(fill=tk.X, pady=(0, 10))

        self.start_button = tk.Button(self.buttons_frame, text="Start Sync", width=14, command=self.start_sync)
        self.start_button.pack(side=tk.LEFT)

        self.stop_button = tk.Button(self.buttons_frame, text="Stop Sync", width=14, command=self.stop_sync, state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=(8, 0))

        self.reset_button = tk.Button(self.buttons_frame, text="Reset Settings", width=14, command=self.reset_settings)
        self.reset_button.pack(side=tk.LEFT, padx=(8, 0))

        self.open_cloud_button = tk.Button(self.buttons_frame, text="Open Cloud Drive", width=16, command=self.open_cloud_drive)
        self.open_cloud_button.pack(side=tk.LEFT, padx=(8, 0))

        status_label = tk.Label(self.buttons_frame, textvariable=self.status, anchor="e")
        status_label.pack(side=tk.RIGHT)

        self.output = tk.Text(self.frame, wrap="word", height=18, state=tk.DISABLED)
        self.output.pack(fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(self.output, command=self.output.yview)
        self.output.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(150, self.drain_output)
        self.refresh_header_links()
        self.refresh_setup_visibility()
        self.refresh_existing_sync_status()

    def load_images(self) -> None:
        try:
            if ICON_PATH.is_file():
                self.icon_image = tk.PhotoImage(file=str(ICON_PATH))
                self.root.iconphoto(True, self.icon_image)
        except tk.TclError:
            self.icon_image = None

        try:
            if LOGO_PATH.is_file():
                original = tk.PhotoImage(file=str(LOGO_PATH))
                width = max(1, original.width())
                height = max(1, original.height())
                max_w = 188
                max_h = 70
                factor = max(1, int(max(width / max_w, height / max_h)))
                self.logo_image = original.subsample(factor, factor)
        except tk.TclError:
            self.logo_image = None

    def build_setup_form(self) -> None:
        help_text = (
            "Upload the contents of the local server folder to public_html/<drive folder>/, "
            "then fill this in and click Save Setup."
        )
        tk.Label(self.setup_frame, text=help_text, anchor="w", justify="left", wraplength=650).grid(
            row=0, column=0, columnspan=3, sticky="ew", pady=(0, 8)
        )

        fields = [
            ("Domain", self.domain_var, False),
            ("Cloud drive folder", self.drive_var, False),
            ("Local folder", self.local_var, False),
            ("FreeCloud password", self.password_var, True),
        ]
        for row, (label, variable, secret) in enumerate(fields, start=1):
            tk.Label(self.setup_frame, text=label).grid(row=row, column=0, sticky="w", pady=3)
            entry = tk.Entry(self.setup_frame, textvariable=variable, show="*" if secret else "")
            entry.grid(row=row, column=1, sticky="ew", padx=(8, 8), pady=3)

        autostart = tk.Checkbutton(
            self.setup_frame,
            text="Autostart at startup",
            variable=self.autostart_var,
            onvalue=True,
            offvalue=False,
        )
        autostart.grid(row=5, column=1, sticky="w", pady=(6, 0))

        self.setup_button = tk.Button(self.setup_frame, text="Save Setup", command=self.save_setup)
        self.setup_button.grid(row=6, column=1, sticky="w", pady=(8, 0))

        self.setup_frame.columnconfigure(1, weight=1)

    def refresh_setup_visibility(self) -> None:
        if LAST_CONFIG_PATH.is_file():
            self.setup_frame.pack_forget()
            return
        self.setup_frame.pack(fill=tk.X, pady=(0, 12), before=self.buttons_frame)

    def refresh_header_links(self) -> None:
        local_root, _base_url = configured_paths()
        self.local_path_var.set(local_root if local_root else "Not set")

    def open_local_folder(self) -> None:
        local_root, _base_url = configured_paths()
        if not local_root:
            messagebox.showinfo("FreeCloud Sync", "Save setup first, then open the local folder.")
            return
        if not open_folder(local_root):
            messagebox.showinfo("FreeCloud Sync", f"Could not open this folder:\n\n{local_root}")

    def open_cloud_drive(self) -> None:
        _local_root, base_url = configured_paths()
        if not base_url:
            messagebox.showinfo("FreeCloud Sync", "Save setup first, then open the cloud drive.")
            return
        self.append(f"Opening cloud drive: {base_url}\n")
        if not open_url(base_url):
            try:
                self.root.clipboard_clear()
                self.root.clipboard_append(base_url)
                self.root.update()
                messagebox.showinfo(
                    "FreeCloud Sync",
                    "Could not open a browser automatically.\n\n"
                    "The cloud address was copied to your clipboard:\n\n"
                    f"{base_url}",
                )
            except tk.TclError:
                messagebox.showinfo("FreeCloud Sync", f"Open this address in your browser:\n\n{base_url}")

    def append(self, text: str) -> None:
        self.output.configure(state=tk.NORMAL)
        self.output.insert(tk.END, text)
        self.output.see(tk.END)
        self.output.configure(state=tk.DISABLED)

    def set_running(self, running: bool) -> None:
        self.status.set("Running" if running else "Stopped")
        self.start_button.configure(state=tk.DISABLED if running else tk.NORMAL)
        self.reset_button.configure(state=tk.DISABLED if running else tk.NORMAL)
        self.stop_button.configure(state=tk.NORMAL if running else tk.DISABLED)

    def refresh_existing_sync_status(self) -> None:
        pid = read_running_sync_pid()
        if pid is None:
            return
        self.status.set("Running in background")
        self.start_button.configure(state=tk.DISABLED)
        self.reset_button.configure(state=tk.DISABLED)
        self.stop_button.configure(state=tk.NORMAL)
        self.append(f"FreeCloud sync is already running in the background. PID: {pid}\n")

    def save_setup(self) -> None:
        self.setup_button.configure(state=tk.DISABLED)
        try:
            domain, drive_name, base_url = build_setup_urls(self.domain_var.get(), self.drive_var.get())
            local_root = Path(self.local_var.get()).expanduser().resolve()
            password = self.password_var.get()

            client = cli.FreeCloudClient(base_url, password)
            try:
                ping = client.ping()
            except cli.FreeCloudApiError as exc:
                if exc.code == 409:
                    ping = {"setup": False}
                elif exc.code == 401:
                    messagebox.showerror(
                        "FreeCloud Setup",
                        "The remote drive is already set up, but that password did not work.",
                    )
                    return
                elif exc.code == 404:
                    messagebox.showerror(
                        "FreeCloud Setup",
                        "Could not find freecloud_api.php.\n\n"
                        f"Checked URL:\n{exc.url}\n\n"
                        f"Upload the contents of:\n{cli.APP_DIR}\n\n"
                        f"into public_html/{drive_name}/ on your host.",
                    )
                    return
                else:
                    messagebox.showerror("FreeCloud Setup", f"Could not contact the server:\n{exc}")
                    return

            if not ping.get("setup"):
                client.setup(drive_name, password)

            local_root.mkdir(parents=True, exist_ok=True)
            config = {
                "domain": domain,
                "drive_name": drive_name,
                "base_url": client.base_url,
                "local_root": str(local_root),
                "password": password,
                "interval": cli.DEFAULT_INTERVAL,
                "autostart": bool(self.autostart_var.get()),
            }
            cli.save_json(cli.config_path(local_root), config)
            cli.save_json(cli.LAST_CONFIG_PATH, config)
            autostart_path = configure_autostart(bool(self.autostart_var.get()))
            self.append(f"Saved setup for {client.base_url}\n")
            self.append(f"Local folder: {local_root}\n")
            if self.autostart_var.get():
                self.append(f"Autostart enabled: {autostart_path}\n")
            else:
                self.append("Autostart disabled.\n")
            self.refresh_header_links()
            self.refresh_setup_visibility()
            messagebox.showinfo("FreeCloud Setup", "Setup saved. You can start sync now.")
        except Exception as exc:
            messagebox.showerror("FreeCloud Setup", str(exc))
        finally:
            self.setup_button.configure(state=tk.NORMAL)

    def start_process(self) -> None:
        if self.process is not None and self.process.poll() is None:
            return
        existing_pid = read_running_sync_pid()
        if existing_pid is not None:
            messagebox.showinfo("FreeCloud Sync", f"FreeCloud sync is already running in the background.\n\nPID: {existing_pid}")
            self.refresh_existing_sync_status()
            return
        if not LAST_CONFIG_PATH.is_file():
            messagebox.showinfo("FreeCloud Sync", "Fill in and save first-time setup before starting sync.")
            self.refresh_setup_visibility()
            return

        command = [sys.executable, str(CLI_PATH)]

        self.append("$ " + " ".join(command) + "\n")
        self.process = subprocess.Popen(
            command,
            cwd=str(BASE_DIR),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        SYNC_PID_PATH.write_text(str(self.process.pid), encoding="utf-8")
        self.set_running(True)

        thread = threading.Thread(target=self.read_output, daemon=True)
        thread.start()

    def read_output(self) -> None:
        assert self.process is not None
        assert self.process.stdout is not None
        for line in self.process.stdout:
            self.output_queue.put(line)
        self.process.wait()
        self.output_queue.put(None)

    def drain_output(self) -> None:
        try:
            while True:
                item = self.output_queue.get_nowait()
                if item is None:
                    try:
                        if self.process is not None and SYNC_PID_PATH.read_text(encoding="utf-8").strip() == str(self.process.pid):
                            SYNC_PID_PATH.unlink()
                    except FileNotFoundError:
                        pass
                    self.set_running(False)
                    self.append("\nProcess stopped.\n")
                else:
                    self.append(item)
        except queue.Empty:
            pass
        self.root.after(150, self.drain_output)

    def start_sync(self) -> None:
        self.start_process()

    def stop_sync(self) -> None:
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            self.append("\nStopping sync...\n")
            try:
                if SYNC_PID_PATH.read_text(encoding="utf-8").strip() == str(self.process.pid):
                    SYNC_PID_PATH.unlink()
            except FileNotFoundError:
                pass
            return

        pid = read_running_sync_pid()
        if pid is None:
            self.set_running(False)
            return

        try:
            if platform.system() == "Windows":
                subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            else:
                os.kill(pid, 15)
        except OSError as exc:
            messagebox.showerror("FreeCloud Sync", f"Could not stop background sync:\n\n{exc}")
            return

        try:
            SYNC_PID_PATH.unlink()
        except FileNotFoundError:
            pass

        self.append(f"\nStopped background sync. PID: {pid}\n")
        self.set_running(False)

    def start_detached_sync(self) -> None:
        command = [sys.executable, str(CLI_PATH)]
        log_file = BACKGROUND_LOG_PATH.open("a", encoding="utf-8")
        log_file.write("\n--- FreeCloud background sync started ---\n")
        log_file.flush()

        kwargs = {
            "cwd": str(BASE_DIR),
            "stdin": subprocess.DEVNULL,
            "stdout": log_file,
            "stderr": subprocess.STDOUT,
            "text": True,
        }

        if platform.system() == "Windows":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
        else:
            kwargs["start_new_session"] = True

        process = subprocess.Popen(command, **kwargs)
        SYNC_PID_PATH.write_text(str(process.pid), encoding="utf-8")

    def stop_managed_process(self) -> None:
        if self.process is None or self.process.poll() is not None:
            return

        self.process.terminate()
        try:
            self.process.wait(timeout=4)
        except subprocess.TimeoutExpired:
            self.process.kill()
        try:
            if SYNC_PID_PATH.read_text(encoding="utf-8").strip() == str(self.process.pid):
                SYNC_PID_PATH.unlink()
        except FileNotFoundError:
            pass

    def reset_settings(self) -> None:
        if self.process is not None and self.process.poll() is None:
            messagebox.showinfo("FreeCloud Sync", "Stop sync before resetting settings.")
            return

        config = load_json(LAST_CONFIG_PATH)
        local_root_value = config.get("local_root")
        local_root = Path(str(local_root_value)).expanduser() if local_root_value else None

        paths = [LAST_CONFIG_PATH]
        if local_root is not None:
            paths.append(local_root / ".freecloud_client.json")
            paths.append(local_root / ".freecloud_state.json")
        for default_root in (Path.home() / "FreeCloud", Path.home() / "myCloud"):
            paths.append(default_root / ".freecloud_client.json")
            paths.append(default_root / ".freecloud_state.json")
        paths = list(dict.fromkeys(paths))

        path_list = "\n".join(str(path) for path in paths)
        confirmed = messagebox.askyesno(
            "Reset FreeCloud Settings",
            "Reset local desktop settings?\n\n"
            "This does not delete your synced files and does not reset the website.\n\n"
            f"Files to remove:\n{path_list}",
        )
        if not confirmed:
            return

        removed = []
        missing = []
        for path in paths:
            try:
                path.unlink()
                removed.append(str(path))
            except FileNotFoundError:
                missing.append(str(path))
            except OSError as exc:
                messagebox.showerror("FreeCloud Sync", f"Could not remove:\n{path}\n\n{exc}")
                return

        if removed:
            self.append("\nReset local settings:\n" + "\n".join(removed) + "\n")
        if missing:
            self.append("\nAlready missing:\n" + "\n".join(missing) + "\n")
        self.append("\nNext start will ask first-time setup questions again.\n")
        self.refresh_header_links()
        self.refresh_setup_visibility()
        messagebox.showinfo("FreeCloud Sync", "Local settings were reset.")

    def on_close(self) -> None:
        if self.process is not None and self.process.poll() is None:
            if messagebox.askyesno(
                "FreeCloud Sync",
                "Sync is still running.\n\n"
                "Close and run in background?\n\n"
                "Choose Yes to close this window and keep syncing.\n"
                "Choose No to stop sync and close.",
            ):
                try:
                    self.start_detached_sync()
                except OSError as exc:
                    messagebox.showerror("FreeCloud Sync", f"Could not start background sync:\n\n{exc}")
                    return
                self.stop_managed_process()
                self.root.destroy()
                return
            self.stop_managed_process()
        self.root.destroy()


def main() -> int:
    root = tk.Tk()
    FreeCloudUi(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
